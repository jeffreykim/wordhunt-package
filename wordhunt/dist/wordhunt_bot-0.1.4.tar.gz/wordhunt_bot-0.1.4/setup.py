from setuptools import setup, find_packages

setup(
    name="wordhunt_bot",  # Replace with your package name
    version="0.1.4",  # Start with a semantic version
    author="Jeffrey Kim",
    author_email="jkjeffrey7@gmail.com",
    description="This script will take a string and output possible words in Wordhunt.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/jeffreykim/wordhunt-bot",  # Replace with your repo URL
    packages=find_packages(),  # Automatically finds `my_package`
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",  # Specify the minimum Python version
    entry_points={
        "console_scripts": [
            "wordhunt=wordhunt_package.solver:run",  # Format: name=module:function
        ],
    },
)